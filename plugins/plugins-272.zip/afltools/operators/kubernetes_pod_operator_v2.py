from typing import Any
from types import ModuleType
from airflow.models.taskinstance import Context
from airflow.exceptions import AirflowException
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator as KPO


# kube_config.yaml is stored in s3 dags folder for now and apparently this is where MWAA mounts it
kube_config_path = '/usr/local/airflow/dags/kube_config.yaml'

# K8s Pod Operator profiles folder, relative to Airflow dags folder
k8s_profiles_folder = '_k8s_profiles'

# Attributes that should not be present in DAG task or profile definition. This is because we either want to enforce
# certain conventions or they refer to platform configuration managed by Data DevOps
forbidden_attrs = ['image', 'in_cluster', 'config_file']


def load_profile(profile: str) -> ModuleType:
    """ Loads a K8s Pod Operator profile, basically a python file without the '.py' extension """
    from os import path
    from importlib.machinery import SourceFileLoader
    from importlib.util import spec_from_loader, module_from_spec

    loader = SourceFileLoader(
        profile,
        path.join(
            get_dags_folder(),
            k8s_profiles_folder,
            f'{profile}.profile'
        )
    )
    spec = spec_from_loader(profile, loader)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)

    return module


def load_image_tag(profile: str) -> str:
    """ Loads image tag from <profile>.image file, as updated by the CI/CD pipeline """
    from os import path
    with open(
        path.join(
            get_dags_folder(),
            k8s_profiles_folder,
            f'{profile}.image'
        ),
        'r'
    ) as _f:
        image = _f.read().rstrip()

    return image


def get_dags_folder() -> str:
    """ Retrives DAGs folder, Airflow 2.X """
    from os import environ
    dags_folder = environ.get('AIRFLOW__CORE__DAGS_FOLDER')
    if not dags_folder:
        from airflow import configuration as conf
        dags_folder = conf.get('core', 'DAGS_FOLDER')

    return dags_folder


def validate_attrs(task_attrs: dict, profile_attrs: dict) -> None:
    """ Validate task and profile parameters """
    for attr in forbidden_attrs:
        if task_attrs.get(attr):
            raise AirflowException(f'Forbidden attribute: {attr}, found in task parameters.')

    for attr in forbidden_attrs:
        if profile_attrs.get(attr):
            raise AirflowException(f'Forbidden attribute: {attr}, found in profile.')

    if not task_attrs.get('labels'):
        raise AirflowException('Task attribute: labels, is required.')
    elif not isinstance(task_attrs.get('labels'), dict):
        raise AirflowException('Task attribute: labels, must have dict type.')
    elif not task_attrs['labels'].get('team'):
        raise AirflowException('Task attribute: labels, requires key: team.')


class KubernetesPodOperator(KPO):
    """ Wrapper for KubernetesPodOperator """
    def __init__(self, **kw) -> None:
        try:
            self.profile = kw.pop('profile')
        except KeyError:
            raise AirflowException(
                f"Required profile argument for task_id: {kw.get('task_id')} is missing."
            )
        # For simplicity we want to have the same POD name as the AFL task_id
        kw['name'] = kw.get('name', kw['task_id'])
        # We need this to be able to tell when to overwrite from profile. More specific, if a parameter value comes
        # from KPO defaults then we overwrite, if it comes from task parameters then we don't.
        self.kw = kw
        super().__init__(**kw)

    def execute(self, context: Context) -> Any:
        """
        Overwrite __init__ attributes of KubernetesPodOperator with profile specific ones.
        We validate and overwrite here to avoid extra processing and I/O operations at each DAGs refresh interval.
        """
        # Validate profile attribute format
        _profile = self.profile.split('.')

        if len(_profile) == 1:
            profile, configuration = _profile[0], "default"
        elif len(_profile) == 2:
            profile, configuration = _profile
        else:
            raise AirflowException('Required profile argument must have the format <profile>[.<configuration>].')

        self.log.info(f"Got profile: {profile}, configuration: {configuration}")

        # Load profile, basically KubernetesPodOperator attributes
        profile_module = load_profile(profile)
        profile_configuration = getattr(profile_module, configuration)

        # Load repo/profile image tag
        profile_image = load_image_tag(profile)
        self.log.info(f'Will use image: {profile_image}')

        # Validate attributes
        validate_attrs(self.kw, profile_configuration)

        # Set KubernetesPodOperator attributes, tasks attributes take precedence
        for attr in profile_configuration:
            if attr in self.kw:
                continue
            setattr(self, attr, profile_configuration[attr])

        # Set/overwrite attributes, specific for a given profile, EKS cluster, etc
        setattr(self, 'image', profile_image)
        self.in_cluster = False
        self.config_file = kube_config_path

        # Execute KubernetesPodOperator
        result = super().execute(context)

        # When XCOM we have to pass the result
        if self.do_xcom_push:
            return result
